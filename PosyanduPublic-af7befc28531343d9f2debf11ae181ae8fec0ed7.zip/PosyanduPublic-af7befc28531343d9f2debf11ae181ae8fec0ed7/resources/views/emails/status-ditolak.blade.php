<!DOCTYPE html>
<html>
<head>
    <title>Status Pendaftaran Ditolak</title>
</head>
<body>
    <h2>Halo, {{ $user->nama_lengkap }}!</h2>
    <p>Terima kasih atas partisipasi Anda dalam proses pendaftaran. Setelah mempertimbangkan dengan cermat, kami harus menyampaikan bahwa pendaftaran Anda saat ini <strong>TIDAK DITERIMA</strong>.</p>
    <p>Kami memahami bahwa ini mungkin tidak sesuai harapan Anda, namun jangan berkecil hati. Kami tetap menghargai minat Anda untuk bergabung dengan kami.</p>
    <p>Jika Anda ingin mengetahui lebih lanjut mengenai alasan penolakan atau membutuhkan bantuan lainnya, silakan hubungi kami melalui email atau telepon.</p>
    <p>Terima kasih atas pengertian Anda.<br>Salam hangat,<br>Tim Kami</p>
</body>
</html>
