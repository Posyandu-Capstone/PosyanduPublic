<!-- resources/views/emails/user_registered.blade.php -->
<h1>New User Registered</h1>
<p>A new user has registered:</p>
<p>Name: {{ $userName }}</p>
<p>NIK: {{ $nik }}</p>
<p>Kontak: {{ $kontak }}</p>
