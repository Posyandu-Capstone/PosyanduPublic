<!DOCTYPE html>
<html>
<head>
    <title>Status Pendaftaran Diterima</title>
</head>
<body>
    <h2>Selamat, {{ $user->nama_lengkap }}!</h2>
    <p>Dengan senang hati kami menginformasikan bahwa pendaftaran Anda telah <strong>DITERIMA</strong>.</p>
    <p>Terima kasih telah bergabung dengan kami! Kami sangat menantikan kontribusi Anda sebagai bagian dari komunitas kami.</p>
    <p>Jika Anda memiliki pertanyaan lebih lanjut, jangan ragu untuk menghubungi kami melalui email atau telepon.</p>
    <p>Salam hangat,<br>Tim Kami</p>
</body>
</html>
